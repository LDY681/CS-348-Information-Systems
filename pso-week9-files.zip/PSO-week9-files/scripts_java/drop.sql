drop table Enrolled;
drop table Class;
drop table Faculty;
drop table Student;
drop table Department;
