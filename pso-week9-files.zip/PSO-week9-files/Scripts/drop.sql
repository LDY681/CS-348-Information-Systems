use nathank;
drop table ENROLLED;
drop table CLASS;
drop table FACULTY;
drop table STUDENT;
drop table DEPARTMENTS;

