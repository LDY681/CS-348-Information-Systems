USE "loginId";
drop table Appointment;
drop table Affiliated_With;
drop table Nurse;
drop table Patient;
drop table Department;
drop table Physician;