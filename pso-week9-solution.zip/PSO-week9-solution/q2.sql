use loginid;
DELIMITER $$
CREATE PROCEDURE ADD_FACULTY(IN fid INT, IN fname TEXT,IN deptid INT) 
BEGIN
	INSERT INTO FACULTY VALUES(fid, fname, deptid);
END $$

DELIMITER ;

select * from FACULTY;


CALL ADD_FACULTY(2013, 'Smith', 11);


select * from FACULTY;
