use loginid;
drop procedure IF EXISTS average_ages;
DELIMITER $$
create procedure average_ages()
BEGIN
DECLARE avg_age INT;
DECLARE num_students INT;
DECLARE dept TEXT;
DECLARE cur_did INT;
DECLARE noMoreRow INT;
DECLARE cur_age INT;
DECLARE dept_cur CURSOR FOR SELECT DISTINCT deptid FROM STUDENT;
DECLARE age_cur CURSOR FOR SELECT age FROM STUDENT where deptid=cur_did;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET noMoreRow = 0;
OPEN dept_cur;
	ITR:LOOP
	FETCH dept_cur INTO cur_did; 
		IF noMoreRow = 0 THEN	        
	            LEAVE ITR;
	    END IF;
		SET avg_age = 0;
		SET num_students = 0;
		OPEN age_cur;
		ITR2:LOOP
		FETCH age_cur INTO cur_age;
		IF noMoreRow = 0 THEN
				SET noMoreRow = 1;
				CLOSE age_cur;	        
	            LEAVE ITR2;
	    END IF;
			SET avg_age = avg_age + cur_age;
			SET num_students = num_students + 1;
		end LOOP ITR2;
		SET avg_age = avg_age/num_students;
		select dname into dept from DEPARTMENTS where deptid=cur_did;
		select dept,avg_age;
	end LOOP ITR;
	CLOSE dept_cur;
END $$

CALL average_ages();


