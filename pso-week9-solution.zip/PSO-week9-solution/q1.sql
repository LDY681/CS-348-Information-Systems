use <loginid>;
DELIMITER $$
CREATE PROCEDURE students_in_class(IN class_name VARCHAR(255)) 
BEGIN
DECLARE stu_number INT;
DECLARE stu_name TEXT;
DECLARE s_snum INT;
DECLARE noMoreRow INT;
DECLARE enr_cur CURSOR FOR SELECT snum FROM ENROLLED WHERE cname=class_name;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET noMoreRow = 0;
OPEN enr_cur;
	ITR:LOOP
		FETCH enr_cur INTO s_snum;
		IF noMoreRow = 0 THEN
            CLOSE enr_cur;
            LEAVE ITR;
        END IF;
		set stu_number = s_snum;
		select sname into stu_name from STUDENT where snum=stu_number;
		SELECT stu_name;
	end LOOP;
END$$


DELIMITER ;

CALL students_in_class('ENG40000');

